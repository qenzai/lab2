﻿using System;
using System.Drawing;
using System.Windows.Forms;


public class SierpinskiSquareForm : Form
{
    private Panel drawingPanel;
    private Button btnDraw;
    private NumericUpDown numDepth;
    private int depth = 5;

    public SierpinskiSquareForm()
    {
        this.Text = "квадрат Серпінського";
        this.Size = new Size(600, 600);

        drawingPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.White
        };
        drawingPanel.Paint += DrawingPanel_Paint;

        btnDraw = new Button
        {
            Text = "Вирішити",
            Dock = DockStyle.Bottom
        };

        btnDraw.Click += (sender, e) => drawingPanel.Invalidate();

        numDepth = new NumericUpDown
        {
            Minimum = 1,
            Maximum = 7,
            Value = depth,
            Dock = DockStyle.Bottom
        };
        numDepth.ValueChanged += (sender, e) => depth = (int)numDepth.Value;

        this.Controls.Add(drawingPanel);
        this.Controls.Add(btnDraw);
        this.Controls.Add(numDepth);
    }

    private void DrawingPanel_Paint(object sender, PaintEventArgs e)
    {
        Graphics g = e.Graphics;

        Rectangle rect = new Rectangle(100, 100, 400, 400);
        DrawSquare(g, depth, rect);
    }

    private void DrawSquare(Graphics g, int depth, Rectangle rect)
    {
        if (depth == 0)
        {
            g.FillRectangle(Brushes.White, rect);
            return;
        }

        int w = rect.Width / 3;
        int h = rect.Height / 3;

        Rectangle[] squares = new Rectangle[9];
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                squares[i * 3 + j] = new Rectangle(rect.X + j * w, rect.Y + i * h, w, h);
            }
        }

        for (int i = 0; i < squares.Length; i++)
        {
            if (i == 4)
            {
                g.FillRectangle(Brushes.Black, squares[i]);
            }
            else
            {
                DrawSquare(g, depth - 1, squares[i]);
            }

        }
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new SierpinskiSquareForm());
    }
}
